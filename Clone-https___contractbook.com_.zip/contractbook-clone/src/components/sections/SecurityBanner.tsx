"use client";

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export function SecurityBanner() {
  return (
    <section className="bg-blue-light/30 py-16 lg:py-20">
      <div className="container-wide">
        <div className="mx-auto overflow-hidden rounded-xl bg-[#b0cede] p-8 shadow-md md:p-12">
          <div className="flex flex-col items-center justify-between gap-10 md:flex-row">
            <div className="flex-1">
              <h2 className="text-center text-2xl font-bold text-navy md:text-left md:text-3xl lg:text-4xl">
                Stay secure, safe and compliant with Contractbook
              </h2>
              <p className="mt-4 text-center text-navy/80 md:text-left lg:text-lg">
                Contractbook is SOC 2 certified, offering secure electronic signatures. It also provides SSO and a robust
                API for granular document and workspace permissions.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4 md:justify-start">
                <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
                  <Button size="lg" className="bg-navy text-white transition-colors hover:bg-navy/90">
                    Sign up for free
                  </Button>
                </Link>
                <Link href="#sectionDemo">
                  <Button size="lg" variant="outline" className="border-navy text-navy transition-colors hover:bg-navy/10">
                    Request a demo
                  </Button>
                </Link>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-8">
              <Image
                src="https://ext.same-assets.com/3440864898/605889915.png"
                alt="SOC 2 Certification"
                width={80}
                height={80}
                className="h-16 w-auto transition-transform hover:scale-105"
              />
              <Image
                src="https://ext.same-assets.com/1490582501/1160213590.png"
                alt="GDPR Compliance"
                width={80}
                height={80}
                className="h-16 w-auto transition-transform hover:scale-105"
              />
              <Image
                src="https://ext.same-assets.com/3174836697/1488502450.svg+xml"
                alt="GDPR Badge"
                width={120}
                height={40}
                className="h-12 w-auto transition-transform hover:scale-105"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
