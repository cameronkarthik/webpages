"use client";

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-r from-navy to-blue py-20 text-white lg:py-28">
      {/* Background elements */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className="absolute -left-16 top-0 h-96 w-96 rounded-full bg-blue-500/10 blur-3xl"></div>
        <div className="absolute -right-32 bottom-0 h-96 w-96 rounded-full bg-blue-500/20 blur-3xl"></div>
        <svg
          className="absolute right-0 top-10 h-auto w-64 text-yellow/10 lg:top-24 lg:w-96"
          viewBox="0 0 200 200"
          fill="currentColor"
        >
          <path d="M51.5,121.5 C51.5,121.5 61.5,131.5 71.5,131.5 C81.5,131.5 91.5,121.5 101.5,121.5 C111.5,121.5 121.5,131.5 131.5,131.5 C141.5,131.5 151.5,121.5 151.5,121.5 L151.5,23.5 C151.5,23.5 141.5,33.5 131.5,33.5 C121.5,33.5 111.5,23.5 101.5,23.5 C91.5,23.5 81.5,33.5 71.5,33.5 C61.5,33.5 51.5,23.5 51.5,23.5 L51.5,121.5 Z"></path>
        </svg>
      </div>

      <div className="container-wide relative z-10">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-20">
          {/* Text column */}
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl font-bold leading-tight tracking-tight md:text-5xl lg:text-6xl">
              Control your contracts
              <br />
              <span className="text-yellow-light">with confidence & ease</span>
            </h1>
            <p className="mt-6 text-lg leading-relaxed text-blue-50">
              Everything you need to manage, track, and finalize contracts — all in one clear, actionable space.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white bg-transparent text-white transition-colors hover:bg-white hover:text-navy"
                >
                  Sign up for free
                </Button>
              </Link>
              <Link href="#sectionDemo">
                <Button
                  size="lg"
                  className="bg-yellow font-medium text-navy transition-colors hover:bg-yellow/90"
                >
                  Request a demo
                </Button>
              </Link>
            </div>
            <div className="mt-8 flex items-center gap-4">
              <Image
                src="https://ext.same-assets.com/357147597/4197593596.svg+xml"
                alt="G2 Logo"
                width={24}
                height={24}
                className="h-6 w-auto"
              />
              <span className="text-sm font-medium text-blue-50">G2 rating: 4.7</span>

              <Image
                src="https://ext.same-assets.com/3007428259/2661452146.svg+xml"
                alt="Capterra rating for Contractbook"
                width={125}
                height={25}
                className="h-5 w-auto"
              />
            </div>
          </div>

          {/* Image column */}
          <div className="relative flex items-center justify-center lg:justify-end">
            <div className="relative rounded-lg shadow-2xl">
              <div className="absolute -left-8 -top-8 h-32 w-32 rounded-full bg-yellow opacity-20 blur-lg lg:-left-16 lg:-top-16"></div>
              <div className="absolute -right-8 -bottom-8 h-32 w-32 rounded-full bg-blue-light opacity-20 blur-lg"></div>
              <Image
                src="https://ext.same-assets.com/1679513433/396847698.png"
                alt="Contractbook Dashboard"
                width={600}
                height={400}
                className="relative z-10 rounded-lg border border-gray-700/20 shadow-xl"
              />
              <div className="absolute top-4 -right-6 z-20 animate-pulse">
                <Image
                  src="https://ext.same-assets.com/3451290300/3936194047.svg+xml"
                  alt="Star decoration"
                  width={80}
                  height={80}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
