"use client";

import React from 'react';
import Image from 'next/image';

interface Testimonial {
  quote: string;
  author: {
    name: string;
    title: string;
    image: string;
  };
  logo: string;
}

const testimonials: Testimonial[] = [
  {
    quote: "Better, more consistent sales agreements faster.",
    author: {
      name: "Ulrich Svarrer",
      title: "CEO @ Bonzer",
      image: "https://ext.same-assets.com/3450916142/248506260.png"
    },
    logo: "https://ext.same-assets.com/2806136437/3810826566.svg+xml"
  },
  {
    quote: "Great overview of all our legal documents.",
    author: {
      name: "Mads Vieth",
      title: "CFO @ Viggo",
      image: "https://ext.same-assets.com/3332406707/3457510377.png"
    },
    logo: "https://ext.same-assets.com/2683797787/457530533.svg+xml"
  }
];

export function TestimonialsSection() {
  return (
    <section className="bg-lilac-light py-16 lg:py-24">
      <div className="container-wide">
        <h2 className="mb-12 text-center text-3xl font-bold text-navy md:text-4xl lg:text-5xl">
          Lose your headaches, not your contracts, deals, or opportunities.
        </h2>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="group rounded-xl bg-white p-8 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md"
            >
              <div className="mb-6">
                <Image
                  src={testimonial.logo}
                  alt="Company logo"
                  width={120}
                  height={40}
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-xl font-bold text-navy">{testimonial.quote}</p>

              <div className="mt-8 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Image
                    src={testimonial.author.image}
                    alt={testimonial.author.name}
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-navy">{testimonial.author.name}</p>
                    <p className="text-sm text-text-medium">{testimonial.author.title}</p>
                  </div>
                </div>

                <div className="opacity-0 transition-opacity group-hover:opacity-100">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-blue"
                  >
                    <path d="m9 18 6-6-6-6"/>
                  </svg>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-20">
          <div className="flex flex-col items-center">
            <Image
              src="https://ext.same-assets.com/1536422267/87909530.svg+xml"
              alt="Clients section divider"
              width={300}
              height={16}
              className="mb-8 h-4 w-auto"
            />
            <p className="mb-12 text-center text-lg text-navy">
              Putting the power of your contracts back in your hands, however small or mighty they may be:
            </p>

            <div className="flex flex-wrap items-center justify-center gap-8 lg:gap-12">
              {[
                "https://ext.same-assets.com/1802425842/95602908.png",
                "https://ext.same-assets.com/1134347535/626709499.png",
                "https://ext.same-assets.com/3246097324/2990440147.png",
                "https://ext.same-assets.com/2860389974/137994640.png",
                "https://ext.same-assets.com/4153082162/611636357.png",
                "https://ext.same-assets.com/922265727/1839832532.png",
                "https://ext.same-assets.com/3223715876/2684832726.png",
                "https://ext.same-assets.com/2934795996/904173107.png",
                "https://ext.same-assets.com/4248743527/3991698113.png",
              ].map((logo, index) => (
                <Image
                  key={index}
                  src={logo}
                  alt="Client logo"
                  width={120}
                  height={40}
                  className="h-10 w-auto opacity-60 grayscale transition-all hover:opacity-100 hover:grayscale-0"
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
