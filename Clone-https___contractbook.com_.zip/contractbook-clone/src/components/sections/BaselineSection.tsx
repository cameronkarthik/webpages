"use client";

import React from 'react';

export function BaselineSection() {
  return (
    <section className="bg-gray-50 py-20 lg:py-28">
      <div className="container-wide">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold text-navy md:text-4xl lg:text-5xl">
            Set a baseline of success for{' '}
            <span className="font-normal italic text-navy">your contracts in 2025</span>
          </h2>
          <p className="mt-6 text-lg text-text-medium leading-relaxed">
            As your budgets get squeezed even tighter, every decision counts! Having a clear overview of your contracts
            means seeing all available opportunities at the right time—ASAP!
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {/* Import & Extract Card */}
          <div className="group rounded-xl bg-white p-8 shadow-sm transition-shadow hover:shadow-md">
            <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-mint/10">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-mint">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
            </div>
            <h3 className="text-xl font-bold text-navy">Import & Extract</h3>
            <p className="mt-4 text-text-medium">
              See your past, present, and future revenue to execute big decisions with proof.
            </p>

            <ul className="mt-6 space-y-3">
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-mint">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Make confident decisions with complete visibility.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-mint">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Access all contracts and agreements at a glance, whenever you need them.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-mint">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Spot opportunities for renewals and growth while avoiding unwanted surprises.</span>
              </li>
            </ul>
          </div>

          {/* Insights Card */}
          <div className="group rounded-xl bg-white p-8 shadow-sm transition-shadow hover:shadow-md">
            <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-coral/10">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-coral">
                <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4c0-1.1.9-2 2-2h8a2 2 0 0 1 2 2v5Z"></path>
                <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1"></path>
              </svg>
            </div>
            <h3 className="text-xl font-bold text-navy">Insights</h3>
            <p className="mt-4 text-text-medium">
              Avoid financial risk and costly mistakes, at every stage of your contracts.
            </p>

            <ul className="mt-6 space-y-3">
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-coral">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Stay in control at every stage of your contracts.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-coral">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Never miss a deadline or face unexpected penalties again. Ensure nothing slips through the cracks by setting renewal reminders and assigned responsibilities.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-coral">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">You decide who does what, and when.</span>
              </li>
            </ul>
          </div>

          {/* Create Card */}
          <div className="group rounded-xl bg-white p-8 shadow-sm transition-shadow hover:shadow-md">
            <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-light/20">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                <path d="M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h9"></path>
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"></path>
                <path d="M16 19h6"></path>
                <path d="M19 16v6"></path>
              </svg>
            </div>
            <h3 className="text-xl font-bold text-navy">Create, collaborate & sign</h3>
            <p className="mt-4 text-text-medium">
              Speed the time to sign with one tool to draft, negotiate and agree
            </p>

            <ul className="mt-6 space-y-3">
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-blue">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Draft, negotiate, and finalize contracts effortlessly.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-blue">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Save your contracts from human-error with customizable templates that put an end to the copy-paste slow down.</span>
              </li>
              <li className="flex items-start gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 flex-shrink-0 text-blue">
                  <polyline points="20 6 9 17 4 12"></polyline>
                </svg>
                <span className="text-gray-700">Keep negotiations moving forward with guard-rails at every step and instant access to the latest version. Send, track and finalise signatures effortlessly.</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
