import React from 'react';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export function DemoSection() {
  return (
    <section id="sectionDemo" className="bg-gray-50 py-16 lg:py-24">
      <div className="container-wide">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold text-navy md:text-4xl">
            Learn more about Contractbook
          </h2>
          <p className="mt-4 text-text-medium">
            Half the work in fixing a problem, is admitting you have one! We're ready to show you why Contractbook could
            be the perfect way to solve your contract-headaches. No pressure—just solutions that make sense.
          </p>
          <div className="mt-6 space-y-2 text-text-medium">
            <p>Your goals, your demo: Tell us what you need, and we'll tailor a 1:1 walkthrough just for you.</p>
            <p>No fluff, just answers: See exactly how Contractbook simplifies your contracts, saves time, and eliminates costly mistakes.</p>
            <p className="font-medium">Fill the form and then choose a time that works for you - Speak to you soon!</p>
          </div>
          <div className="mt-4 flex items-center justify-center gap-2">
            <Image
              src="https://ext.same-assets.com/357147597/4197593596.svg+xml"
              alt="G2 Logo"
              width={24}
              height={24}
              className="h-5 w-auto"
            />
            <span className="text-sm text-text-medium">G2 rating: 4.7</span>
          </div>
        </div>

        <div className="mt-12">
          <div className="mx-auto max-w-3xl rounded-xl bg-white p-8 shadow-lg">
            <h3 className="text-center text-xl font-bold text-navy">Schedule your free demo</h3>

            <div className="mt-6 flex justify-center">
              <div className="flex w-full max-w-md items-center justify-between">
                <div className="flex flex-col items-center">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-navy text-white">1</div>
                  <span className="mt-2 text-sm">Fill out the form</span>
                </div>
                <div className="h-[2px] w-16 bg-gray-200"></div>
                <div className="flex flex-col items-center">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-200 text-gray-500">2</div>
                  <span className="mt-2 text-sm text-gray-500">Book a time</span>
                </div>
                <div className="h-[2px] w-16 bg-gray-200"></div>
                <div className="flex flex-col items-center">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gray-200 text-gray-500">3</div>
                  <span className="mt-2 text-sm text-gray-500">Join your 1:1 demo</span>
                </div>
              </div>
            </div>

            <form className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
              <div>
                <Label htmlFor="first-name">First name*</Label>
                <Input id="first-name" type="text" className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="last-name">Last name*</Label>
                <Input id="last-name" type="text" className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="email">Email*</Label>
                <Input id="email" type="email" className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="department">Department</Label>
                <Input id="department" type="text" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="company">Company name</Label>
                <Input id="company" type="text" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="job-title">Job title</Label>
                <Input id="job-title" type="text" className="mt-1" />
              </div>
              <div className="md:col-span-2">
                <Label htmlFor="website">Company website*</Label>
                <Input id="website" type="url" className="mt-1" required />
              </div>
              <div>
                <Label htmlFor="company-size">Company size</Label>
                <select
                  id="company-size"
                  className="mt-1 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="">Select...</option>
                  <option value="1-10">1-10 employees</option>
                  <option value="11-50">11-50 employees</option>
                  <option value="51-200">51-200 employees</option>
                  <option value="201-500">201-500 employees</option>
                  <option value="500+">500+ employees</option>
                </select>
              </div>
              <div>
                <Label htmlFor="industry">Industry</Label>
                <select
                  id="industry"
                  className="mt-1 w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                >
                  <option value="">Select...</option>
                  <option value="tech">Technology</option>
                  <option value="finance">Financial Services</option>
                  <option value="legal">Legal Services</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="healthcare">Healthcare</option>
                  <option value="other">Other</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <p className="text-xs text-gray-500">
                  Contractbook needs the contact information you provide to us to contact you about our products and services.
                  To learn more, review our <a href="/legal/privacy-policy" className="text-blue">Privacy Policy</a>.
                </p>
              </div>
              <div className="md:col-span-2">
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                  Schedule Demo
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
