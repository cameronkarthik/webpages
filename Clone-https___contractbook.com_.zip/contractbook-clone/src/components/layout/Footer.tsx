"use client";

import React from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Separator } from '@/components/ui/separator';

interface FooterLinkGroup {
  title: string;
  links: {
    name: string;
    href: string;
    isExternal?: boolean;
  }[];
}

const footerLinks: FooterLinkGroup[] = [
  {
    title: 'Product',
    links: [
      { name: 'Create, Collaborate & Sign', href: '/product/create-contracts' },
      { name: 'Centralize', href: '/product/centralized-contract-repository' },
      { name: 'Insights', href: '/product/data-driven-insights' },
      { name: 'Pricing', href: '/pricing' },
      { name: 'Security', href: '/product/security' },
    ],
  },
  {
    title: 'Use cases',
    links: [
      { name: 'Contract Lifecycle Management', href: '/contract-lifecycle-management' },
      { name: 'Contract Management', href: '/contract-management' },
      { name: 'Digital Signature', href: '/lp/esignature' },
      { name: 'Contract Automation', href: '/contract-automation' },
      { name: 'AI Contract Management', href: '/ai-contract-management' },
      { name: 'Contract Analysis Software', href: '/contract-analysis-software' },
    ],
  },
  {
    title: 'Integrate',
    links: [
      { name: 'Hubspot', href: '/product/integration/hubspot' },
      { name: 'Salesforce', href: '/product/integration/salesforce' },
      { name: 'API Documentation', href: 'https://api.contractbook.com/', isExternal: true },
    ],
  },
  {
    title: 'Resources',
    links: [
      { name: 'Webinars', href: '/webinars' },
      { name: 'Customer stories', href: '/customers' },
      { name: 'Contract templates', href: '/templates' },
      { name: 'Learn', href: '/learn' },
      { name: 'Blog', href: '/blog' },
      { name: 'Dictionary', href: '/dictionary' },
    ],
  },
  {
    title: 'Company',
    links: [
      { name: 'About us', href: '/company/about-us' },
      { name: 'Jobs - We are hiring!', href: '#' },
      { name: 'Careers', href: 'https://contractbook.teamtailor.com/', isExternal: true },
      { name: 'Request DPA', href: 'https://contractbook.com/create-dpa' },
      { name: 'Security', href: '/product/security' },
      { name: 'Press', href: '/press' },
    ],
  },
];

const contactInfo = {
  office: {
    title: 'Copenhagen Office (HQ)',
    address: 'Farvergade 2, 4. 1463 København K',
    country: 'Denmark',
    phone: '+45 89 87 78 38',
  },
  support: {
    title: 'Support',
    links: [
      { name: 'Help Center', href: 'https://support.contractbook.com' },
      { name: 'Service status', href: 'https://status.contractbook.com/' },
    ],
  },
  contact: {
    title: 'Contact',
    sections: [
      {
        title: 'Live chat and email:',
        items: [
          { text: 'support@contractbook.com', href: 'mailto:support@contractbook.com' },
          { text: '4:00 AM- 5:00 PM(ET) / 9:00 - 23:00 (CET)' },
        ],
      },
      {
        title: 'Phone support:',
        items: [
          { text: '+45 89 87 78 38', href: 'tel:+4589877838' },
          { text: '9:00 - 17:00 (CET)' },
          { text: '+1 680-215-0190', href: 'tel:+16802150190' },
          { text: '9:00 AM - 5:00 PM (ET)' },
        ],
      },
      {
        title: 'Finance:',
        items: [
          { text: '+45 71 68 89 42', href: 'tel:+4571688942' },
          { text: '9:00 - 17:00 (CET)' },
        ],
      },
    ],
  },
};

export function Footer() {
  return (
    <footer className="bg-[#1d1c4b] text-white">
      <div className="container-wide py-12">
        {/* Top links section */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-6">
          {/* Logo */}
          <div className="col-span-1 lg:col-span-1">
            <Link href="/" className="inline-block">
              <Image
                src="https://ext.same-assets.com/2310167920/663636435.svg+xml"
                alt="Contractbook"
                width={130}
                height={32}
                className="h-8 w-auto"
              />
            </Link>
          </div>

          {/* Links */}
          {footerLinks.map((group) => (
            <div key={group.title} className="col-span-1">
              <h3 className="mb-4 font-bold">{group.title}</h3>
              <ul className="space-y-2 text-sm">
                {group.links.map((link) => (
                  <li key={link.name}>
                    {link.isExternal ? (
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="opacity-75 transition-opacity hover:opacity-100"
                      >
                        {link.name}
                      </a>
                    ) : (
                      <Link
                        href={link.href}
                        className="opacity-75 transition-opacity hover:opacity-100"
                      >
                        {link.name}
                      </Link>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact information section */}
        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-3">
          {/* Office */}
          <div>
            <h3 className="mb-4 font-bold">{contactInfo.office.title}</h3>
            <p className="text-sm opacity-75">{contactInfo.office.address}</p>
            <p className="text-sm opacity-75">{contactInfo.office.country}</p>
            <a
              href={`tel:${contactInfo.office.phone}`}
              className="mt-2 block text-sm opacity-75 transition-opacity hover:opacity-100"
            >
              {contactInfo.office.phone}
            </a>
          </div>

          {/* Support */}
          <div>
            <h3 className="mb-4 font-bold">{contactInfo.support.title}</h3>
            <ul className="space-y-2 text-sm">
              {contactInfo.support.links.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="opacity-75 transition-opacity hover:opacity-100"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 font-bold">{contactInfo.contact.title}</h3>
            {contactInfo.contact.sections.map((section, index) => (
              <div key={index} className="mb-4">
                <p className="text-sm font-medium">{section.title}</p>
                <ul className="mt-1 space-y-1 text-sm">
                  {section.items.map((item, idx) => (
                    <li key={idx} className="opacity-75">
                      {item.href ? (
                        <a
                          href={item.href}
                          className="transition-opacity hover:opacity-100"
                        >
                          {item.text}
                        </a>
                      ) : (
                        item.text
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Social Media */}
        <div className="mt-12 flex items-center space-x-4">
          <a
            href="https://www.facebook.com/contractbook/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Facebook"
          >
            <Image
              src="https://ext.same-assets.com/1600674051/2984753275.svg+xml"
              alt="Facebook"
              width={24}
              height={24}
              className="opacity-75 transition-opacity hover:opacity-100"
            />
          </a>
          <a
            href="https://twitter.com/contractbook"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Twitter"
          >
            <Image
              src="https://ext.same-assets.com/3228310793/2526077805.svg+xml"
              alt="Twitter"
              width={24}
              height={24}
              className="opacity-75 transition-opacity hover:opacity-100"
            />
          </a>
          <a
            href="https://www.linkedin.com/company/contractbook/"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
          >
            <Image
              src="https://ext.same-assets.com/4226195841/595791495.svg+xml"
              alt="LinkedIn"
              width={24}
              height={24}
              className="opacity-75 transition-opacity hover:opacity-100"
            />
          </a>
          <a
            href="https://www.glassdoor.com/Overview/Working-at-Contractbook-EI_IE4147222.11,23.htm"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Glassdoor"
          >
            <Image
              src="https://ext.same-assets.com/2410476096/3423855490.svg+xml"
              alt="Glassdoor"
              width={24}
              height={24}
              className="opacity-75 transition-opacity hover:opacity-100"
            />
          </a>
        </div>

        {/* Security Information */}
        <div className="mt-8 text-sm opacity-75">
          <p>
            We care about the security of our platform. If you have found a security issue,
            please contact us at{' '}
            <a
              href="mailto:security@contractbook.com"
              className="underline transition-opacity hover:opacity-100"
            >
              security@contractbook.com
            </a>
          </p>
        </div>

        {/* Bottom Section */}
        <div className="mt-8">
          <Separator className="mb-8 bg-gray-700 opacity-30" />
          <div className="flex flex-col justify-between space-y-4 md:flex-row md:space-y-0">
            <div className="text-sm opacity-75">
              © 2025 Contractbook ApS | DK-36890649
            </div>
            <div className="flex flex-wrap gap-4 text-sm">
              <Link
                href="/legal/terms"
                className="opacity-75 transition-opacity hover:opacity-100"
              >
                Terms & Conditions
              </Link>
              <Link
                href="/legal/privacy-policy"
                className="opacity-75 transition-opacity hover:opacity-100"
              >
                Privacy policy
              </Link>
              <button className="opacity-75 transition-opacity hover:opacity-100">
                Cookie settings
              </button>
              <Link
                href="/legal/cookie-policy"
                className="opacity-75 transition-opacity hover:opacity-100"
              >
                Cookie policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
