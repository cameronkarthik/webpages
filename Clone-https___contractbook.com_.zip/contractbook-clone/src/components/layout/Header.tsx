"use client";

import React, { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface ProductLinkType {
  name: string;
  href: string;
  icon?: string;
  description?: string;
}

const productLinks: ProductLinkType[] = [
  {
    name: 'Centralize with AI',
    href: '/product/centralized-contract-repository',
    icon: 'centralize',
    description: 'Work smarter and faster with Contractbook\'s built-in AI'
  },
  {
    name: 'Get insights with data',
    href: '/product/data-driven-insights',
    icon: 'insights',
    description: 'Track, extract, and identify opportunities at a glance'
  },
  {
    name: 'Create, collaborate & sign',
    href: '/product/create-contracts',
    icon: 'create',
    description: 'Draft, negotiate, and finalize contracts in one place'
  },
];

const templateLinks = [
  { name: 'Other', href: '/template-category/other' },
  { name: 'Featured', href: '/template-category/featured' },
  { name: 'Employment', href: '/template-category/employment' },
  { name: 'Sales', href: '/template-category/sales-contract-templates' },
  { name: 'Real estate', href: '/template-category/rental' },
  { name: 'HR', href: '/template-category/hr' },
  { name: 'Confidentiality', href: '/template-category/confidentiality' },
  { name: 'Intellectual property', href: '/template-category/intellectual-property' },
  { name: 'Corporate', href: '/template-category/corporate' },
];

export function Header() {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);

  const handleDropdownTrigger = (name: string) => {
    setActiveDropdown(activeDropdown === name ? null : name);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-gray-100 bg-white">
      <div className="container-wide flex h-16 items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center">
            <Image
              src="https://ext.same-assets.com/1014820285/2209374328.svg+xml"
              alt="Contractbook Logo"
              width={130}
              height={32}
              className="h-8 w-auto"
            />
          </Link>

          <nav className="hidden lg:flex items-center space-x-1">
            {/* Product Dropdown */}
            <div className="relative">
              <button
                onClick={() => handleDropdownTrigger('product')}
                className={`flex items-center gap-1 px-3 py-2 text-sm font-medium transition-colors hover:text-blue ${activeDropdown === 'product' ? 'text-blue' : 'text-gray-700'}`}
              >
                Product
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className={`h-4 w-4 transition-transform ${activeDropdown === 'product' ? 'rotate-180' : ''}`}
                >
                  <path d="m6 9 6 6 6-6"/>
                </svg>
              </button>

              {activeDropdown === 'product' && (
                <div className="absolute left-0 top-full z-50 mt-1 w-full min-w-[560px] overflow-hidden rounded-lg border border-gray-100 bg-white p-0 shadow-lg">
                  <div className="grid grid-cols-1">
                    <div className="p-4">
                      <div className="grid gap-4">
                        {productLinks.map((link) => (
                          <Link
                            key={link.href}
                            href={link.href}
                            className="flex items-start gap-3 rounded-lg p-3 transition-colors hover:bg-gray-50"
                            onClick={() => setActiveDropdown(null)}
                          >
                            <div className="mt-1 flex h-8 w-8 items-center justify-center rounded-full bg-blue-light/20">
                              {link.icon === 'centralize' && (
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                                  <rect width="18" height="18" x="3" y="3" rx="2" />
                                  <path d="M3 9h18" />
                                  <path d="M9 21V9" />
                                </svg>
                              )}
                              {link.icon === 'insights' && (
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                                  <path d="M3 3v18h18" />
                                  <path d="m19 9-5 5-4-4-3 3" />
                                </svg>
                              )}
                              {link.icon === 'create' && (
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                </svg>
                              )}
                            </div>
                            <div>
                              <div className="font-medium text-navy">{link.name}</div>
                              <div className="text-sm text-gray-500">{link.description}</div>
                            </div>
                          </Link>
                        ))}
                      </div>
                      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-gray-100 pt-4">
                        <div className="text-sm text-gray-500">
                          All features included in our centralized platform
                        </div>
                        <Link
                          href="/pricing"
                          className="text-sm font-medium text-blue"
                          onClick={() => setActiveDropdown(null)}
                        >
                          View pricing
                        </Link>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Templates Dropdown */}
            <div className="relative">
              <button
                onClick={() => handleDropdownTrigger('templates')}
                className={`flex items-center gap-1 px-3 py-2 text-sm font-medium transition-colors hover:text-blue ${activeDropdown === 'templates' ? 'text-blue' : 'text-gray-700'}`}
              >
                Templates
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className={`h-4 w-4 transition-transform ${activeDropdown === 'templates' ? 'rotate-180' : ''}`}
                >
                  <path d="m6 9 6 6 6-6"/>
                </svg>
              </button>

              {activeDropdown === 'templates' && (
                <div className="absolute left-0 top-full z-50 mt-1 min-w-[240px] overflow-hidden rounded-lg border border-gray-100 bg-white p-0 shadow-lg">
                  <div className="p-2">
                    {templateLinks.map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className="block w-full rounded-md px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 hover:text-blue"
                        onClick={() => setActiveDropdown(null)}
                      >
                        {link.name}
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Other Navigation Links */}
            <Link
              href="/pricing"
              className="px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:text-blue"
            >
              Packages
            </Link>

            <Link
              href="/customers"
              className="px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:text-blue"
            >
              Customers
            </Link>

            <Link
              href="/learn"
              className="px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:text-blue"
            >
              Learn
            </Link>
          </nav>
        </div>

        <div className="flex items-center space-x-2">
          <Link href="https://app.contractbook.com/login" className="hidden md:block">
            <Button variant="ghost" size="sm" className="font-medium text-gray-700 hover:text-blue">
              Login
            </Button>
          </Link>
          <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
            <Button variant="ghost" size="sm" className="font-medium text-gray-700 hover:text-blue">
              Free Trial
            </Button>
          </Link>
          <Link href="/demo/info">
            <Button size="sm" className="bg-blue font-medium text-white hover:bg-blue/90">
              Request a demo
            </Button>
          </Link>

          {/* Mobile Menu */}
          <Sheet>
            <SheetTrigger asChild className="lg:hidden">
              <Button variant="ghost" size="icon" className="ml-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6">
                  <line x1="4" x2="20" y1="12" y2="12" />
                  <line x1="4" x2="20" y1="6" y2="6" />
                  <line x1="4" x2="20" y1="18" y2="18" />
                </svg>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] p-0">
              <div className="flex h-16 items-center border-b border-gray-100 px-6">
                <Link href="/" className="flex items-center">
                  <Image
                    src="https://ext.same-assets.com/1014820285/2209374328.svg+xml"
                    alt="Contractbook Logo"
                    width={130}
                    height={32}
                    className="h-8 w-auto"
                  />
                </Link>
              </div>
              <div className="overflow-y-auto p-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="text-sm font-semibold text-gray-500">Products</div>
                    {productLinks.map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className="block py-2 text-base font-medium text-navy hover:text-blue"
                      >
                        {link.name}
                      </Link>
                    ))}
                  </div>

                  <div className="space-y-2 border-t border-gray-100 pt-4">
                    <div className="text-sm font-semibold text-gray-500">Resources</div>
                    <Link
                      href="/templates"
                      className="block py-2 text-base font-medium text-navy hover:text-blue"
                    >
                      Templates
                    </Link>
                    <Link
                      href="/pricing"
                      className="block py-2 text-base font-medium text-navy hover:text-blue"
                    >
                      Packages
                    </Link>
                    <Link
                      href="/customers"
                      className="block py-2 text-base font-medium text-navy hover:text-blue"
                    >
                      Customers
                    </Link>
                    <Link
                      href="/learn"
                      className="block py-2 text-base font-medium text-navy hover:text-blue"
                    >
                      Learn
                    </Link>
                  </div>

                  <div className="border-t border-gray-100 pt-4">
                    <div className="space-y-3">
                      <Link href="https://app.contractbook.com/login">
                        <Button variant="outline" size="lg" className="w-full justify-center">
                          Login
                        </Button>
                      </Link>
                      <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
                        <Button variant="outline" size="lg" className="w-full justify-center">
                          Free Trial
                        </Button>
                      </Link>
                      <Link href="/demo/info">
                        <Button size="lg" className="w-full justify-center bg-blue hover:bg-blue/90">
                          Request a demo
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Backdrop for when dropdown is open */}
      {activeDropdown && (
        <div
          className="fixed inset-0 z-40 bg-black/20"
          onClick={() => setActiveDropdown(null)}
        />
      )}
    </header>
  );
}
