import { NextFont } from 'next/dist/compiled/@next/font';
import localFont from 'next/font/local';

// Load ABC Whyte font
export const abcWhyte = localFont({
  src: [
    {
      path: '../../public/fonts/ABCWhyte-Regular.woff',
      weight: '400',
      style: 'normal',
    },
    {
      path: '../../public/fonts/ABCWhyte-RegularItalic.woff',
      weight: '400',
      style: 'italic',
    },
    {
      path: '../../public/fonts/ABCWhyte-Bold.woff',
      weight: '700',
      style: 'normal',
    },
    {
      path: '../../public/fonts/ABCWhyte-BoldItalic.woff',
      weight: '700',
      style: 'italic',
    },
  ],
  variable: '--font-abc-whyte',
});
