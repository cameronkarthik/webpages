import type { Metadata } from "next";
import { abcWhyte } from "@/lib/fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: "Contractbook: Contract Management Software",
  description: "Contract management software to store and manage contracts, so you can analyze, decide and act quicker from one central place.",
  icons: {
    icon: '/favicon.ico',
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${abcWhyte.variable} font-sans antialiased`}>
        {children}
      </body>
    </html>
  );
}
