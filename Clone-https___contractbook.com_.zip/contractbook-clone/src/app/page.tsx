import { RootLayout } from '@/components/layout/RootLayout';
import { HeroSection } from '@/components/sections/HeroSection';
import { BaselineSection } from '@/components/sections/BaselineSection';
import { SecurityBanner } from '@/components/sections/SecurityBanner';
import { TestimonialsSection } from '@/components/sections/TestimonialsSection';
import { DemoSection } from '@/components/sections/DemoSection';

export default function Home() {
  return (
    <RootLayout>
      <HeroSection />
      <BaselineSection />
      <SecurityBanner />
      <TestimonialsSection />
      <DemoSection />
    </RootLayout>
  );
}
