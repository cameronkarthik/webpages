import { RootLayout } from '@/components/layout/RootLayout';
import { Button } from '@/components/ui/button';
import { DemoSection } from '@/components/sections/DemoSection';
import Image from 'next/image';
import Link from 'next/link';

export default function DataDrivenInsightsPage() {
  return (
    <RootLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#f9f9f9] to-[#f3f3f3] py-16 lg:py-24">
        <div className="container-wide">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div className="max-w-2xl">
              <div className="mb-2 text-sm font-medium text-navy">Product</div>
              <h1 className="text-4xl font-bold text-navy md:text-5xl">
                <span className="font-bold">Get insights</span> from data so you make better{' '}
                <em className="font-normal italic">business decisions</em>
              </h1>
              <p className="mt-6 text-text-medium">
                With all your contracts in one place, you can quickly search, track, and extract data to identify opportunities, trends, and more.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
                  <Button size="lg" className="bg-blue text-white hover:bg-blue/90">
                    Start free trial
                  </Button>
                </Link>
                <Link href="#sectionDemo">
                  <Button size="lg" variant="outline" className="border-navy text-navy hover:bg-navy/10">
                    Request a demo
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <Image
                src="https://ext.same-assets.com/1261352719/3891165917.webp"
                alt="Data-Driven Insights"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
              <div className="absolute top-4 -right-4">
                <Image
                  src="https://ext.same-assets.com/3629781978/3611975640.svg+xml"
                  alt="Play video"
                  width={80}
                  height={80}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Value Proposition */}
      <section className="py-20">
        <div className="container-wide">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold text-navy md:text-4xl">
              Unlock the total value<br />
              of<em className="font-normal italic">your contract data</em>
            </h2>
          </div>

          {/* Feature Sections */}
          <div className="mt-20">
            {/* Views Feature */}
            <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="order-2 flex flex-col justify-center md:order-1">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-light">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                    <rect width="18" height="18" x="3" y="3" rx="2" />
                    <path d="M3 9h18" />
                    <path d="M9 21V9" />
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Have a clear overview of your contracts and their details</h3>
                <p className="mt-4 text-text-medium">
                  With all your contracts centralized, you'll always have an overview of important details and contract data. No more time wasted hunting them down in emails, folders, and sub-folders.
                </p>
                <p className="mt-4 text-text-medium">
                  Plus, you can quickly find the right contracts and organize them based on the relevant criteria exactly when you need them.
                </p>
              </div>
              <div className="order-1 md:order-2">
                <div className="relative overflow-hidden rounded-lg bg-blue-600">
                  <Image
                    src="https://ext.same-assets.com/3041805960/1877740474.jpeg"
                    alt="Clear Overview Feature"
                    width={600}
                    height={400}
                    className="w-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="rounded-full bg-white/10 p-4 backdrop-blur-sm">
                      <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                        <polygon points="5 3 19 12 5 21 5 3"></polygon>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Filter & Columns Feature */}
            <div className="mt-24 grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="flex flex-col justify-center">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-mint/20">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-mint">
                    <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Filter, search, sort, and organize your contracts</h3>
                <p className="mt-4 text-text-medium">
                  Whether it's legal, financial, or other contract data, any static contract can be turned into a powerful database, giving you the information you need in seconds without extra admin work.
                </p>
                <p className="mt-4 text-text-medium">
                  Customize your views by filtering through source templates or contract types, then add relevant data fields as columns. With Contractbook, organizing your contracts becomes a breeze, putting essential information at your fingertips.
                </p>
              </div>
              <div>
                <Image
                  src="https://ext.same-assets.com/3900043273/4142027659.png"
                  alt="Filter and Search Feature"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>

            {/* Notifications Feature */}
            <div className="mt-24 grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="order-2 flex flex-col justify-center md:order-1">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-coral/20">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-coral">
                    <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9" />
                    <path d="M10.3 21a1.94 1.94 0 0 0 3.4 0" />
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Never miss a deadline again</h3>
                <p className="mt-4 text-text-medium">
                  Dive deep into your contract data and stay on top of renewals, deadlines, and obligations with automatic reminders and tasks.
                </p>
                <p className="mt-4 text-text-medium">
                  Drawing from the contract data stored in the centralized repository, Contractbook lets you set up recurring reminders and notifications based on contract data fields.
                </p>
                <p className="mt-4 text-text-medium">
                  Want a better deal and money saved? Use the AI-generated insights to start renegotiations faster with automatic reminders. Plus, de-risk agreements and empower your business to make more strategic decisions.
                </p>
              </div>
              <div className="order-1 md:order-2">
                <Image
                  src="https://ext.same-assets.com/3900043273/4142027659.png"
                  alt="Notifications Feature"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Demo Section */}
      <section className="bg-blue-600 py-16 text-white">
        <div className="container-wide">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold md:text-4xl">
              See how easy it is to visualize<br />
              your contract data
            </h2>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button size="lg" variant="outline" className="border-white bg-transparent text-white hover:bg-white hover:text-blue-600">
                Explore live product
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-lilac-light py-16">
        <div className="container-wide">
          <h2 className="mb-8 text-center text-3xl font-bold text-navy md:text-4xl">
            Better decisions<br />
            start with a complete overview
          </h2>
          <p className="mx-auto mb-12 max-w-2xl text-center text-text-medium">
            From 95% no-touch contracts to over 250 hours saved, having a centralized overview is where it all starts.
          </p>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="rounded-xl bg-white p-8 shadow-sm">
              <div className="mb-6">
                <Image
                  src="https://ext.same-assets.com/2806136437/3810826566.svg+xml"
                  alt="Bonzer Logo"
                  width={120}
                  height={40}
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-navy">
                Contractbook empowers our sales team to make better, more consistent sales agreements faster. We get more control of our funnel and activate autonomy in every team at the same time, which makes our setup easy to scale and enables us to identify where we can improve. Since we implemented this sales agreement workflow, we have tripled our output.
              </p>
              <div className="mt-8 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Image
                    src="https://ext.same-assets.com/3450916142/248506260.png"
                    alt="Ulrich Svarrer"
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-navy">Ulrich Svarrer</p>
                    <p className="text-sm text-text-medium">CEO @ Bonzer</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-white p-8 shadow-sm">
              <div className="mb-6">
                <Image
                  src="https://ext.same-assets.com/2683797787/457530533.svg+xml"
                  alt="Viggo Logo"
                  width={120}
                  height={40}
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-navy">
                "By using Contractbook, we have a great overview of all our legal documents. Our team has easy access to all the right templates, we can follow our contracts through their lifecycle, and it's easy to see what is the next step in the process."
              </p>
              <div className="mt-8 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Image
                    src="https://ext.same-assets.com/3332406707/3457510377.png"
                    alt="Mads Vieth"
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-navy">Mads Vieth</p>
                    <p className="text-sm text-text-medium">CFO @ Viggo</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <DemoSection />
    </RootLayout>
  );
}
