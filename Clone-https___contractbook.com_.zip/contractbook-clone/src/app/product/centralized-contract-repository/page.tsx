import { RootLayout } from '@/components/layout/RootLayout';
import { Button } from '@/components/ui/button';
import { DemoSection } from '@/components/sections/DemoSection';
import Image from 'next/image';
import Link from 'next/link';

export default function CentralizedRepositoryPage() {
  return (
    <RootLayout>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-[#f9f9f9] to-[#f3f3f3] py-16 lg:py-24">
        <div className="container-wide">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div className="max-w-2xl">
              <div className="mb-2 text-sm font-medium text-navy">Product</div>
              <h1 className="text-4xl font-bold text-navy md:text-5xl">
                <span className="font-bold">Centralize</span> your contracts{' '}
                <em className="font-normal italic">using AI</em>
              </h1>
              <p className="mt-6 text-text-medium">
                Work smarter and faster with Contractbook's built-in AI. Centralize agreements, extract data, automate tasks, and offer secure access for your entire team.
              </p>
              <div className="mt-8 flex flex-wrap gap-4">
                <Link href="https://app.contractbook.com/sign-up?signup_type=trial&source_type=inbound">
                  <Button size="lg" className="bg-blue text-white hover:bg-blue/90">
                    Start free trial
                  </Button>
                </Link>
                <Link href="#sectionDemo">
                  <Button size="lg" variant="outline" className="border-navy text-navy hover:bg-navy/10">
                    Request a demo
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <Image
                src="https://ext.same-assets.com/2528280485/1648829826.webp"
                alt="Centralized Contract Repository"
                width={500}
                height={400}
                className="rounded-lg shadow-lg"
              />
              <div className="absolute top-4 -right-4">
                <Image
                  src="https://ext.same-assets.com/3629781978/3611975640.svg+xml"
                  alt="Play video"
                  width={80}
                  height={80}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Value Proposition */}
      <section className="py-20">
        <div className="container-wide">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold text-navy md:text-4xl">
              One home to store and manage<br />
              all your contracts <em className="font-normal italic">powered by AI</em>
            </h2>
          </div>

          {/* Feature Sections */}
          <div className="mt-20">
            {/* Import AI Feature */}
            <div className="grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="order-2 flex flex-col justify-center md:order-1">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-blue-light">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-blue">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                    <polyline points="17 8 12 3 7 8" />
                    <line x1="12" y1="3" x2="12" y2="15" />
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Import contracts at AI speed</h3>
                <p className="mt-4 text-text-medium">
                  Imagine you have a stack of contracts piled high on your local drive and inbox, waiting to be processed (or not). Instead of spending countless hours sifting through them and updating a spreadsheet, AI does the heavy lifting for you in a few clicks.
                </p>
                <p className="mt-4 text-text-medium">
                  Simply drag and drop. Our built-in AI will scan and extract the important data in your contracts. No human handling, no human error. Just the speed of AI.
                </p>
              </div>
              <div className="order-1 md:order-2">
                <div className="relative overflow-hidden rounded-lg bg-blue-600">
                  <Image
                    src="https://ext.same-assets.com/1410614298/1343005281.jpeg"
                    alt="AI Import Feature"
                    width={600}
                    height={400}
                    className="w-full object-cover"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="rounded-full bg-white/10 p-4 backdrop-blur-sm">
                      <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-white">
                        <polygon points="5 3 19 12 5 21 5 3"></polygon>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Extract Data Feature */}
            <div className="mt-24 grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="flex flex-col justify-center">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-mint/20">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-mint">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="3" y1="9" x2="21" y2="9"></line>
                    <line x1="9" y1="21" x2="9" y2="9"></line>
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Extract contract data automatically</h3>
                <p className="mt-4 text-text-medium">
                  Searching through PDF contracts to find one clause or detail is not the best use of your time. With Contractbook, AI puts an end to wasted hours of hunting for more information.
                </p>
                <p className="mt-4 text-text-medium">
                  Filter using names, dates, or specific data fields, and save the filters you'll use again for future use, allowing you to analyze, decide, and act quicker.
                </p>
              </div>
              <div>
                <Image
                  src="https://ext.same-assets.com/1627296637/2761283206.jpeg"
                  alt="Data Extraction Feature"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>

            {/* Reminders Feature */}
            <div className="mt-24 grid grid-cols-1 gap-12 md:grid-cols-2 lg:gap-20">
              <div className="order-2 flex flex-col justify-center md:order-1">
                <div className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-yellow/20">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow">
                    <path d="M10.42 11.88c-1.03-.7-1.23-1.74-.5-2.86.54-.81 1.41-1.32 2.25-1.5"></path>
                    <path d="m12.17 7.52 1.13-3.89"></path>
                    <path d="M14.02 9.76c3.97.5 4.55 2.5 4.55 5.69 0 2.65-2.13 3.94-3.97 2.95"></path>
                    <path d="M16.74 12.05c1.13.17 1.81.92 1.84 2.22"></path>
                    <path d="M4.83 5.91A9.96 9.96 0 0 0 2 12c0 5.52 4.48 10 10 10 1.17 0 2.3-.2 3.34-.59"></path>
                    <path d="M5 19.92a9.92 9.92 0 0 1-2-6.09c0-5.25 4.09-9.53 9.25-9.9"></path>
                    <path d="M10.25 13.75c-.15.61-.25 1.21-.27 1.76-.01.31.14.65.47.88.63.43 1.31 1.24 1.87 1.65.21.15.47.24.76.15.56-.17 1.15-.73 1.7-1.07.46-.29.63-.79.62-1.32-.04-1.47-.53-3.01-1.56-4.44"></path>
                  </svg>
                </div>
                <h3 className="mt-6 text-2xl font-bold text-navy">Be proactive and start renegotiations faster</h3>
                <p className="mt-4 text-text-medium">
                  Staying on top of crucial dates is hard. No wonder they slip through the cracks and leave you scrambling at every renewal or important deadline.
                </p>
                <p className="mt-4 text-text-medium">
                  By extracting renewal and expiry dates, AI enables you to be proactive without the headache of maintaining an overview yourself.
                </p>
                <p className="mt-4 text-text-medium">
                  Want a better deal and money saved? Use that information to start renegotiations faster with automatic reminders. Plus, de-risk agreements and empower your business to make more strategic decisions.
                </p>
              </div>
              <div className="order-1 md:order-2">
                <Image
                  src="https://ext.same-assets.com/3601029762/1044225456.jpeg"
                  alt="Reminders Feature"
                  width={600}
                  height={400}
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Walkthrough Section */}
      <section className="bg-blue-600 py-16 text-white">
        <div className="container-wide">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold md:text-4xl">
              See how just one click turns<br />
              static agreements into powerful insights
            </h2>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button size="lg" variant="outline" className="border-white bg-transparent text-white hover:bg-white hover:text-blue-600">
                Explore live product
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="bg-lilac-light py-16">
        <div className="container-wide">
          <h2 className="mb-8 text-center text-3xl font-bold text-navy md:text-4xl">
            Better decisions<br />
            start with a complete overview
          </h2>
          <p className="mx-auto mb-12 max-w-2xl text-center text-text-medium">
            From 95% no-touch contracts to over 250 hours saved, having a centralized overview is where it all starts.
          </p>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="rounded-xl bg-white p-8 shadow-sm">
              <div className="mb-6">
                <Image
                  src="https://ext.same-assets.com/2806136437/3810826566.svg+xml"
                  alt="Bonzer Logo"
                  width={120}
                  height={40}
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-navy">
                Contractbook empowers our sales team to make better, more consistent sales agreements faster. We get more control of our funnel and activate autonomy in every team at the same time, which makes our setup easy to scale and enables us to identify where we can improve. Since we implemented this sales agreement workflow, we have tripled our output.
              </p>
              <div className="mt-8 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Image
                    src="https://ext.same-assets.com/3450916142/248506260.png"
                    alt="Ulrich Svarrer"
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-navy">Ulrich Svarrer</p>
                    <p className="text-sm text-text-medium">CEO @ Bonzer</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-xl bg-white p-8 shadow-sm">
              <div className="mb-6">
                <Image
                  src="https://ext.same-assets.com/2683797787/457530533.svg+xml"
                  alt="Viggo Logo"
                  width={120}
                  height={40}
                  className="h-8 w-auto"
                />
              </div>
              <p className="text-navy">
                "By using Contractbook, we have a great overview of all our legal documents. Our team has easy access to all the right templates, we can follow our contracts through their lifecycle, and it's easy to see what is the next step in the process."
              </p>
              <div className="mt-8 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Image
                    src="https://ext.same-assets.com/3332406707/3457510377.png"
                    alt="Mads Vieth"
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium text-navy">Mads Vieth</p>
                    <p className="text-sm text-text-medium">CFO @ Viggo</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <DemoSection />
    </RootLayout>
  );
}
