import FeaturesSection from "@/components/FeaturesSection";
import Footer from "@/components/Footer";
import HeroSection from "@/components/HeroSection";
import IntegrationsSection from "@/components/IntegrationsSection";
import Navbar from "@/components/Navbar";
import StepsSection from "@/components/StepsSection";
import TestimonialsSection from "@/components/TestimonialsSection";

export default function Home() {
  return (
    <main>
      <Navbar />
      <div className="pt-16">
        <HeroSection />
        <FeaturesSection />
        <StepsSection />
        <IntegrationsSection />
        <TestimonialsSection />
        <Footer />
      </div>
    </main>
  );
}
