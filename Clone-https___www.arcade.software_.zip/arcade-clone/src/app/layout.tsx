import type { Metadata } from "next";
import "./globals.css";
import ClientBody from "./ClientBody";

export const metadata: Metadata = {
  title: "Arcade - Create Interactive Demos that convert",
  description: "Arcade is an interactive demo platform that allows teams to create effortlessly beautiful demos in minutes.",
  icons: {
    icon: [
      {
        url: "https://ext.same-assets.com/2884040683/100544478.svg+xml",
        href: "https://ext.same-assets.com/2884040683/100544478.svg+xml",
      },
    ],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="font-sans">
      <ClientBody>
        {children}
      </ClientBody>
    </html>
  );
}
