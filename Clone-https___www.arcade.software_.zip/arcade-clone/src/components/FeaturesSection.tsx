'use client';

import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import Link from "next/link";
import { Button } from "./ui/button";

const FeaturesSection = () => {
  return (
    <section className="py-24 bg-background border-t border-gray-100">
      <div className="container max-w-7xl">
        <h2 className="text-3xl sm:text-4xl font-bold text-center mb-4">
          Demos for the whole team.
        </h2>
        <p className="text-lg text-muted-foreground text-center mb-16 max-w-2xl mx-auto">
          Arcade makes building, collaborating, and scaling seamless, no matter your team size.
        </p>

        <Tabs defaultValue="marketing" className="w-full">
          <div className="flex justify-center mb-10">
            <TabsList className="h-auto p-1 bg-muted/40 border border-gray-200 rounded-lg shadow-sm overflow-hidden flex flex-wrap">
              <TabsTrigger
                value="marketing"
                className="px-5 py-3 text-sm font-medium rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary"
              >
                Marketing
              </TabsTrigger>
              <TabsTrigger
                value="product"
                className="px-5 py-3 text-sm font-medium rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary"
              >
                Product
              </TabsTrigger>
              <TabsTrigger
                value="sales"
                className="px-5 py-3 text-sm font-medium rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary"
              >
                Sales & Pre-sales
              </TabsTrigger>
              <TabsTrigger
                value="customer-success"
                className="px-5 py-3 text-sm font-medium rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary"
              >
                Customer Success
              </TabsTrigger>
              <TabsTrigger
                value="enablement"
                className="px-5 py-3 text-sm font-medium rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm data-[state=active]:text-primary"
              >
                Enablement & Training
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="marketing" className="mt-0 border border-gray-100 rounded-2xl p-8 shadow-sm bg-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="flex flex-col gap-6">
                <h3 className="text-2xl font-bold">
                  <span className="text-muted-foreground font-normal">Arcade</span>
                  <span className="text-primary">for marketing</span>
                </h3>
                <p className="text-muted-foreground text-lg">
                  Build compelling, on-brand demos in minutes to drive leads, boost product adoption, and more effectively tell your product's story.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="font-medium">Chapters</div>
                  <div className="font-medium">Call-to-action buttons</div>
                  <div className="font-medium">Export to GIF/Video</div>
                  <div className="font-medium">White-labeled Arcades</div>
                </div>
                <div>
                  <Link href="/solutions/marketing">
                    <Button variant="link" className="font-medium text-primary p-0 flex items-center">
                      Learn more
                      <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </Button>
                  </Link>
                </div>
                <div className="rounded-lg bg-muted/40 p-4 flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                  </div>
                  <p className="font-medium">Up to 5x trial conversion</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <img
                  src="https://ext.same-assets.com/3693876849/3316650394.svg+xml"
                  alt="Marketing dashboard"
                  className="w-full h-auto p-4 object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="product" className="mt-0 border border-gray-100 rounded-2xl p-8 shadow-sm bg-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="flex flex-col gap-6">
                <h3 className="text-2xl font-bold">
                  <span className="text-muted-foreground font-normal">Arcade</span>
                  <span className="text-primary">for product</span>
                </h3>
                <p className="text-muted-foreground text-lg">
                  Demos built for fast-paced product teams looking to drive adoption, gather feedback quickly, and iterate on concepts.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="font-medium">Forms</div>
                  <div className="font-medium">Product analytics</div>
                  <div className="font-medium">Integrations</div>
                  <div className="font-medium">Branching</div>
                </div>
                <div>
                  <Link href="/solutions/product">
                    <Button variant="link" className="font-medium text-primary p-0 flex items-center">
                      Learn more
                      <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </Button>
                  </Link>
                </div>
                <div className="rounded-lg bg-muted/40 p-4 flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                  </div>
                  <p className="font-medium">Up to 30% more activated users</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <img
                  src="https://ext.same-assets.com/3693876849/3316650394.svg+xml"
                  alt="Product dashboard"
                  className="w-full h-auto p-4 object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sales" className="mt-0 border border-gray-100 rounded-2xl p-8 shadow-sm bg-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="flex flex-col gap-6">
                <h3 className="text-2xl font-bold">
                  <span className="text-muted-foreground font-normal">Arcade</span>
                  <span className="text-primary">for sales & pre-sales</span>
                </h3>
                <p className="text-muted-foreground text-lg">
                  Create engaging, personalized demos in minutes to win buyers early, showcase your product, and accelerate sales cycles.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="font-medium">Collections</div>
                  <div className="font-medium">Custom links</div>
                  <div className="font-medium">Camera recording</div>
                </div>
                <div>
                  <Link href="/solutions/sales">
                    <Button variant="link" className="font-medium text-primary p-0 flex items-center">
                      Learn more
                      <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </Button>
                  </Link>
                </div>
                <div className="rounded-lg bg-muted/40 p-4 flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                  </div>
                  <p className="font-medium">More than 2x demo conversion</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <img
                  src="https://ext.same-assets.com/3693876849/3316650394.svg+xml"
                  alt="Sales dashboard"
                  className="w-full h-auto p-4 object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="customer-success" className="mt-0 border border-gray-100 rounded-2xl p-8 shadow-sm bg-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="flex flex-col gap-6">
                <h3 className="text-2xl font-bold">
                  <span className="text-muted-foreground font-normal">Arcade</span>
                  <span className="text-primary">for customer success</span>
                </h3>
                <p className="text-muted-foreground text-lg">
                  Scale your impact through engaging, informative content designed to educate customers, increase product adoption, and build customer loyalty.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="font-medium">Custom variables</div>
                  <div className="font-medium">Branching</div>
                  <div className="font-medium">Chapters</div>
                </div>
                <div>
                  <Link href="/solutions/sales">
                    <Button variant="link" className="font-medium text-primary p-0 flex items-center">
                      Learn more
                      <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </Button>
                  </Link>
                </div>
                <div className="rounded-lg bg-muted/40 p-4 flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                  </div>
                  <p className="font-medium">Save over 3k hours onboarding</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <img
                  src="https://ext.same-assets.com/3693876849/3316650394.svg+xml"
                  alt="Customer Success dashboard"
                  className="w-full h-auto p-4 object-cover"
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="enablement" className="mt-0 border border-gray-100 rounded-2xl p-8 shadow-sm bg-white">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div className="flex flex-col gap-6">
                <h3 className="text-2xl font-bold">
                  <span className="text-muted-foreground font-normal">Arcade</span>
                  <span className="text-primary">for enablement & training</span>
                </h3>
                <p className="text-muted-foreground text-lg">
                  Save time, energy, and resources on content creation. Easily create demos and learn from how your audience engages to quickly iterate and improve.
                </p>
                <div className="space-y-3 text-sm">
                  <div className="font-medium">Camera recording</div>
                  <div className="font-medium">Synthetic voiceover</div>
                  <div className="font-medium">Hotspots and Callouts</div>
                  <div className="font-medium">Collections</div>
                </div>
                <div>
                  <Link href="/solutions/product">
                    <Button variant="link" className="font-medium text-primary p-0 flex items-center">
                      Learn more
                      <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </Button>
                  </Link>
                </div>
                <div className="rounded-lg bg-muted/40 p-4 flex items-center gap-3">
                  <div className="bg-primary/10 rounded-full p-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="20"
                      height="20"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="text-primary"
                    >
                      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17"></polyline>
                      <polyline points="16 7 22 7 22 13"></polyline>
                    </svg>
                  </div>
                  <p className="font-medium">Up to 10x faster than creating a video</p>
                </div>
              </div>
              <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
                <img
                  src="https://ext.same-assets.com/3693876849/3316650394.svg+xml"
                  alt="Enablement dashboard"
                  className="w-full h-auto p-4 object-cover"
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default FeaturesSection;
