import Link from "next/link";
import { Separator } from "./ui/separator";

const Footer = () => {
  return (
    <footer className="bg-background py-16">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="flex flex-col gap-4">
            <div className="font-medium text-lg">Product</div>
            <div className="flex flex-col gap-2">
              <Link href="/product" className="text-muted-foreground hover:text-foreground transition-colors">
                Product Overview
              </Link>
              <Link href="/product/capture" className="text-muted-foreground hover:text-foreground transition-colors">
                Lead Generation
              </Link>
              <Link href="/product/personalization" className="text-muted-foreground hover:text-foreground transition-colors">
                Personalization
              </Link>
              <Link href="/integrations" className="text-muted-foreground hover:text-foreground transition-colors">
                Integrations
              </Link>
              <Link href="/pricing" className="text-muted-foreground hover:text-foreground transition-colors">
                Pricing
              </Link>
              <Link href="https://app.arcade.software/auth" className="text-muted-foreground hover:text-foreground transition-colors">
                Login
              </Link>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="font-medium text-lg">Solutions</div>
            <div className="flex flex-col gap-2">
              <Link href="/solutions/marketing" className="text-muted-foreground hover:text-foreground transition-colors">
                For marketing
              </Link>
              <Link href="/solutions/product" className="text-muted-foreground hover:text-foreground transition-colors">
                For product
              </Link>
              <Link href="/solutions/sales" className="text-muted-foreground hover:text-foreground transition-colors">
                For sales
              </Link>
              <Link href="/talk-to-sales" className="text-muted-foreground hover:text-foreground transition-colors">
                Talk to sales
              </Link>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="font-medium text-lg">Resources</div>
            <div className="flex flex-col gap-2">
              <Link href="/blog" className="text-muted-foreground hover:text-foreground transition-colors">
                Blog
              </Link>
              <Link href="https://docs.arcade.software/kb" className="text-muted-foreground hover:text-foreground transition-colors">
                Knowledge Base
              </Link>
              <Link href="/changelog" className="text-muted-foreground hover:text-foreground transition-colors">
                Changelog
              </Link>
              <Link href="/showcase" className="text-muted-foreground hover:text-foreground transition-colors">
                Showcase
              </Link>
              <Link href="/category/case-study" className="text-muted-foreground hover:text-foreground transition-colors">
                Case studies
              </Link>
              <Link href="/build-like-its-2024" className="text-muted-foreground hover:text-foreground transition-colors">
                Build like it's 2024
              </Link>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="font-medium text-lg">Company</div>
            <div className="flex flex-col gap-2">
              <Link href="/careers" className="text-muted-foreground hover:text-foreground transition-colors">
                Careers
              </Link>
              <Link href="/security" className="text-muted-foreground hover:text-foreground transition-colors">
                Security
              </Link>
              <Link href="/brand" className="text-muted-foreground hover:text-foreground transition-colors">
                Brand
              </Link>
              <Link href="https://arcadehq.statuspage.io" className="text-muted-foreground hover:text-foreground transition-colors">
                Status
              </Link>
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <div className="font-medium text-lg">Legal</div>
            <div className="flex flex-col gap-2">
              <Link href="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms-of-service" className="text-muted-foreground hover:text-foreground transition-colors">
                Terms of Service
              </Link>
              <Link href="/dpa" className="text-muted-foreground hover:text-foreground transition-colors">
                DPA
              </Link>
            </div>

            <div className="mt-4">
              <div className="font-medium text-lg">Download</div>
              <div className="flex flex-col gap-2">
                <Link href="/download" className="text-muted-foreground hover:text-foreground transition-colors">
                  Desktop App
                </Link>
                <Link href="https://chrome.google.com/webstore/detail/arcade/gagidkjllbdgggpboolfmmdpeagghjlm" className="text-muted-foreground hover:text-foreground transition-colors">
                  Chrome Extension
                </Link>
              </div>
            </div>
          </div>
        </div>

        <Separator className="my-10" />

        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <Link href="/" className="flex items-center">
            <img
              src="https://ext.same-assets.com/2884040683/100544478.svg+xml"
              alt="Arcade Logo"
              className="h-8 w-8"
            />
            <span className="ml-2 font-semibold text-lg">Arcade</span>
          </Link>

          <div className="text-muted-foreground text-sm">
            The Fastest Way to Create Interactive Demos
          </div>

          <div className="flex gap-4">
            <Link href="https://twitter.com/arcade_demo" className="text-muted-foreground hover:text-foreground transition-colors">
              <span className="sr-only">Twitter</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
                <path d="M5.026 15c6.038 0 9.341-5.003 9.341-9.334 0-.14 0-.282-.006-.422A6.685 6.685 0 0 0 16 3.542a6.658 6.658 0 0 1-1.889.518 3.301 3.301 0 0 0 1.447-1.817 6.533 6.533 0 0 1-2.087.793A3.286 3.286 0 0 0 7.875 6.03a9.325 9.325 0 0 1-6.767-3.429 3.289 3.289 0 0 0 1.018 4.382A3.323 3.323 0 0 1 .64 6.575v.045a3.288 3.288 0 0 0 2.632 3.218 3.203 3.203 0 0 1-.865.115 3.23 3.23 0 0 1-.614-.057 3.283 3.283 0 0 0 3.067 2.277A6.588 6.588 0 0 1 .78 13.58a6.32 6.32 0 0 1-.78-.045A9.344 9.344 0 0 0 5.026 15z"/>
              </svg>
            </Link>
            <Link href="https://www.linkedin.com/company/arcadehq/" className="text-muted-foreground hover:text-foreground transition-colors">
              <span className="sr-only">LinkedIn</span>
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
                <path d="M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854V1.146zm4.943 12.248V6.169H2.542v7.225h2.401zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248-.822 0-1.359.54-1.359 1.248 0 .694.521 1.248 1.327 1.248h.016zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016a5.54 5.54 0 0 1 .016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225h2.4z"/>
              </svg>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
