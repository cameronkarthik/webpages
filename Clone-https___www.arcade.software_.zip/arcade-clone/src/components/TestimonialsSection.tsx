'use client';

import { Card, CardContent } from "./ui/card";
import Link from "next/link";
import { Button } from "./ui/button";

const TestimonialsSection = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8">
            You're in great company.
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            How our customers use Arcade to drive impact
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <Card className="bg-white border shadow-sm overflow-hidden">
            <CardContent className="p-8">
              <blockquote className="mb-8">
                <p className="text-lg mb-6">
                  "Arcade allowed us to have a much more focused narrative to tell the story we wanted."
                </p>
                <footer className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
                    <img
                      src="https://ext.same-assets.com/1816508648/1651890852.svg+xml"
                      alt="Trevor Pyle"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">Trevor Pyle</p>
                    <p className="text-sm text-muted-foreground">Sr. Director, Product Marketing & Strategy @ Quantum Metric</p>
                  </div>
                </footer>
              </blockquote>
              <Link href="https://www.arcade.software/post/quantum-metric">
                <Button variant="outline" className="w-full">Read story</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white border shadow-sm overflow-hidden">
            <CardContent className="p-8">
              <blockquote className="mb-8">
                <p className="text-lg mb-6">
                  "Arcade is one of the most important ways for us to showcase the product and allow our web visitors and prospects to self-educate even before they jump into the product."
                </p>
                <footer className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
                    <img
                      src="https://ext.same-assets.com/323765669/37327143.svg+xml"
                      alt="Danielle Russell"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">Danielle Russell</p>
                    <p className="text-sm text-muted-foreground">VP Product and Marketing @ Nudge Security</p>
                  </div>
                </footer>
              </blockquote>
              <Link href="https://www.arcade.software/post/nudge-security">
                <Button variant="outline" className="w-full">Read story</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white border shadow-sm overflow-hidden">
            <CardContent className="p-8">
              <blockquote className="mb-8">
                <p className="text-lg mb-6">
                  "The best thing about it [Arcade] is that it allows for very quick iteration. In the time it would take me to do one Figma prototype, I could have created or iterated on three or four Arcades."
                </p>
                <footer className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted overflow-hidden">
                    <img
                      src="https://ext.same-assets.com/1759258653/662621722.svg+xml"
                      alt="Ignacio Moreno Pubul"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <p className="font-medium">Ignacio Moreno Pubul</p>
                    <p className="text-sm text-muted-foreground">Co-founder @ Capchase</p>
                  </div>
                </footer>
              </blockquote>
              <Link href="https://www.arcade.software/post/capchase">
                <Button variant="outline" className="w-full">Read story</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-8 mt-16">
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-1">5x</div>
              <div className="text-sm text-muted-foreground">Increase in trial conversion</div>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-1">4x</div>
              <div className="text-sm text-muted-foreground">Faster to test new product concepts</div>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-1">2x</div>
              <div className="text-sm text-muted-foreground">Conversion rate over Get a Demo page</div>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-1">5x</div>
              <div className="text-sm text-muted-foreground">More engagement vs. video</div>
            </div>
          </div>
          <div className="bg-white rounded-lg border shadow-sm p-6">
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-1">10x</div>
              <div className="text-sm text-muted-foreground">Faster to create Arcade vs. video</div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link href="https://www.arcade.software/category/case-study">
            <Button variant="outline" className="font-medium">
              More customer stories
            </Button>
          </Link>
        </div>

        <div className="mt-24 py-12 px-8 md:px-16 bg-primary/5 rounded-xl border text-center">
          <h2 className="text-3xl font-bold mb-6">
            Build demos that drive action.
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="https://app.arcade.software/auth">
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground text-base font-medium px-6 py-6 h-auto">
                Get started for free
              </Button>
            </Link>
            <Link href="/talk-to-sales">
              <Button variant="outline" className="text-base font-medium px-6 py-6 h-auto">
                Talk to sales
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
