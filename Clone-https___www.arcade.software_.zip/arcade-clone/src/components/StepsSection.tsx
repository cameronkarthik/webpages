'use client';

import { Button } from "./ui/button";
import Link from "next/link";

const StepsSection = () => {
  return (
    <section className="py-28 bg-gradient-to-b from-[#f9fafb] to-[#ffffff]">
      <div className="container max-w-6xl">
        <div className="text-center mb-20">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6">
            The fastest way to tell your story.
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Designed for scale, Arcade allows teams to build interactive demos without relying on technical or creative resources.
          </p>
        </div>

        <div className="space-y-32">
          {/* Step 1 */}
          <div className="relative grid md:grid-cols-2 gap-12 md:gap-16 lg:gap-24 items-center">
            {/* Step Number */}
            <div className="absolute -top-10 left-0 flex items-center gap-2 text-lg font-bold text-primary/80">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm">1</div>
              <span>Record</span>
            </div>

            <div className="order-2 md:order-1">
              <h3 className="text-2xl font-bold mb-4">No code required.</h3>
              <p className="text-muted-foreground mb-6">
                Record on any device using Arcade's Chrome extension, desktop app, or uploaded media. Steps are automatically stitched together.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="https://chrome.google.com/webstore/detail/arcade/gagidkjllbdgggpboolfmmdpeagghjlm">
                  <Button variant="outline" className="font-medium">
                    Install Extension
                  </Button>
                </Link>
                <Link href="/download">
                  <Button variant="outline" className="font-medium">
                    Download Desktop App
                  </Button>
                </Link>
              </div>
              <div className="mt-6 p-5 bg-muted/30 rounded-lg border border-gray-100">
                <p className="text-sm italic text-muted-foreground">
                  "The simplicity is only surpassed by the result. Excellent product!"
                </p>
              </div>
            </div>
            <div className="order-1 md:order-2 bg-white rounded-xl border border-gray-200 p-4 shadow-sm overflow-hidden relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <video
                  className="w-full h-auto rounded-lg"
                  autoPlay
                  muted
                  loop
                  playsInline
                  poster="https://ext.same-assets.com/485318409/1258680981.png"
                >
                  <source src="https://ext.same-assets.com/4273633742/4094251437.mp4" type="video/mp4" />
                </video>
              </div>
            </div>
          </div>

          {/* Step 2 */}
          <div className="relative grid md:grid-cols-2 gap-12 md:gap-16 lg:gap-24 items-center">
            {/* Step Number */}
            <div className="absolute -top-10 left-0 flex items-center gap-2 text-lg font-bold text-primary/80">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm">2</div>
              <span>Edit</span>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm overflow-hidden relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <video
                  className="w-full h-auto rounded-lg"
                  autoPlay
                  muted
                  loop
                  playsInline
                >
                  <source src="https://ext.same-assets.com/1119275753/3620608250.mp4" type="video/mp4" />
                </video>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">On-brand, everytime.</h3>
              <p className="text-muted-foreground mb-6">
                Our easy-to-use builder unlocks creativity while maintaining brand consistency. Boost engagement with voiceovers, branching, and other interactive elements.
              </p>
              <div>
                <Link href="/product">
                  <Button variant="outline" className="font-medium flex items-center">
                    Learn more
                    <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </Button>
                </Link>
              </div>
              <div className="mt-6 p-5 bg-muted/30 rounded-lg border border-gray-100">
                <p className="text-sm italic text-muted-foreground">
                  "We've loved using Arcade to spice up our socials and add interactive demos to our blog posts!"
                </p>
                <div className="flex items-center gap-2 mt-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center">
                    <span className="text-xs font-medium">AL</span>
                  </div>
                  <p className="text-sm font-medium">Aaron Lu</p>
                </div>
              </div>
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative grid md:grid-cols-2 gap-12 md:gap-16 lg:gap-24 items-center">
            {/* Step Number */}
            <div className="absolute -top-10 left-0 flex items-center gap-2 text-lg font-bold text-primary/80">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm">3</div>
              <span>Share and Embed</span>
            </div>

            <div className="order-2 md:order-1">
              <h3 className="text-2xl font-bold mb-4">Distribution made easy.</h3>
              <p className="text-muted-foreground mb-6">
                Embed on your website, share custom links with prospects, or download as a GIF or video for social media.
              </p>
              <div>
                <Link href="/showcase">
                  <Button variant="outline" className="font-medium">
                    See examples
                  </Button>
                </Link>
              </div>
              <div className="mt-6 p-5 bg-muted/30 rounded-lg border border-gray-100">
                <p className="text-sm italic text-muted-foreground">
                  "Crazy! It's like the future of showing a demo on your website."
                </p>
              </div>
            </div>
            <div className="order-1 md:order-2 bg-white rounded-xl border border-gray-200 p-4 shadow-sm overflow-hidden relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <video
                  className="w-full h-auto rounded-lg"
                  autoPlay
                  muted
                  loop
                  playsInline
                >
                  <source src="https://ext.same-assets.com/4273996498/4076195552.mp4" type="video/mp4" />
                </video>
              </div>
            </div>
          </div>

          {/* Step 4 */}
          <div className="relative grid md:grid-cols-2 gap-12 md:gap-16 lg:gap-24 items-center">
            {/* Step Number */}
            <div className="absolute -top-10 left-0 flex items-center gap-2 text-lg font-bold text-primary/80">
              <div className="flex items-center justify-center w-8 h-8 bg-primary/10 rounded-full text-sm">4</div>
              <span>Analyze</span>
            </div>

            <div className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm overflow-hidden relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-50 to-indigo-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              <div className="relative z-10">
                <video
                  className="w-full h-auto rounded-lg"
                  autoPlay
                  muted
                  loop
                  playsInline
                >
                  <source src="https://ext.same-assets.com/4219938900/61784647.mp4" type="video/mp4" />
                </video>
              </div>
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-4">Drive action.</h3>
              <p className="text-muted-foreground mb-6">
                Leverage analytics to identify your viewers, understand how they engage, and drive action.
              </p>
              <div>
                <Link href="/growth">
                  <Button variant="outline" className="font-medium flex items-center">
                    Learn more
                    <svg className="ml-1 h-4 w-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M5 12H19M19 12L12 5M19 12L12 19" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </Button>
                </Link>
              </div>
              <div className="mt-6 p-5 bg-muted/30 rounded-lg border border-gray-100">
                <p className="text-sm italic text-muted-foreground">
                  "Engagement is generally much higher on Arcades vs. images and videos, and we're able to run small tests quite easily."
                </p>
                <div className="flex items-center gap-2 mt-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 overflow-hidden flex items-center justify-center">
                    <span className="text-xs font-medium">AW</span>
                  </div>
                  <p className="text-sm font-medium">Alex Wunderlich</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-32 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold mb-8">
            Ready to create quick, interactive product demos?
          </h2>
          <Link href="https://app.arcade.software/auth">
            <Button className="bg-primary hover:bg-primary/90 text-primary-foreground text-base font-medium px-8 py-6 h-auto rounded-md">
              Sign up - it's free
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default StepsSection;
