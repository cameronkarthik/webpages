'use client';

import Link from "next/link";
import { Button } from "./ui/button";

const IntegrationsSection = () => {
  return (
    <section className="py-28 relative overflow-hidden">
      {/* Background styling */}
      <div className="absolute inset-0 bg-[#351c4d] bg-opacity-95 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[url('https://ext.same-assets.com/2363228796/2389237828.png')] bg-cover opacity-10 mix-blend-overlay"></div>
      </div>

      <div className="container relative z-10 max-w-6xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold mb-5 text-white">
            Integrated with the<span className="hidden sm:inline"> </span><br className="sm:hidden" />tools you rely on.
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Gather deep insights, drive action, and get more done with native integrations
          </p>
        </div>

        <div className="flex justify-center mb-12">
          <Link href="/integrations">
            <Button variant="outline" className="font-medium border-white/20 text-white hover:bg-white/10 hover:text-white">
              Explore all integrations
            </Button>
          </Link>
        </div>

        {/* Integration logos */}
        <div className="relative">
          <div className="flex flex-wrap justify-center items-center gap-12 py-12 px-8 md:px-16 bg-black/10 backdrop-blur-sm rounded-xl border border-gray-700/30">
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/3571723401/1210315351.svg+xml"
                alt="Amplitude"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/1039438105/101351023.svg+xml"
                alt="Google Analytics"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/3379001300/2147683807.png"
                alt="Segment"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/1700828062/318624434.svg+xml"
                alt="Mixpanel"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/876718542/166877284.png"
                alt="GTM"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/3181009896/3003970014.png"
                alt="Meta Pixel"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
            <div className="relative flex-shrink-0 transition-transform hover:scale-110">
              <img
                src="https://ext.same-assets.com/3548138593/1860188944.svg+xml"
                alt="Slack"
                className="h-8 w-auto opacity-80 hover:opacity-100 transition-opacity"
              />
            </div>
          </div>

          {/* Decorative dots */}
          <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-1">
            <div className="w-2 h-2 rounded-full bg-red-400"></div>
            <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
            <div className="w-2 h-2 rounded-full bg-green-400"></div>
            <div className="w-2 h-2 rounded-full bg-blue-400"></div>
            <div className="w-2 h-2 rounded-full bg-purple-400"></div>
          </div>
        </div>

        {/* G2 Review section */}
        <div className="mt-20 text-center">
          <Link href="https://www.g2.com/products/arcade-software-arcade/reviews" className="text-gray-400 hover:text-white flex items-center justify-center gap-2 mb-6">
            <img
              src="https://ext.same-assets.com/1379562457/3047432319.svg+xml"
              alt="G2"
              className="h-5 w-auto"
            />
            <span className="text-sm">See all reviews</span>
          </Link>

          <blockquote className="max-w-2xl mx-auto">
            <p className="text-2xl sm:text-3xl font-serif italic font-medium text-white mb-5">
              "Arcade has made the process of creating and updating demo experiences a breeze."
            </p>
            <footer className="text-gray-300">
              Growth Marketing Manager @ Wrike
            </footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
};

export default IntegrationsSection;
