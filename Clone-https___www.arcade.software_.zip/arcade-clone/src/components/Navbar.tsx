'use client';

import Link from 'next/link';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTrigger } from './ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from './ui/dropdown-menu';
import { useState } from 'react';
import { ChevronDown, Menu } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center">
            <img
              src="https://ext.same-assets.com/2884040683/100544478.svg+xml"
              alt="Arcade Logo"
              className="h-8 w-8"
            />
            <span className="ml-2 font-semibold text-lg">Arcade</span>
          </Link>

          <div className="hidden lg:flex items-center gap-6">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-1 font-medium">
                  Product <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60">
                <div className="grid gap-2 p-2">
                  <DropdownMenuItem asChild>
                    <Link href="/product" className="flex p-2">
                      <div>
                        <div className="font-medium">Product Overview</div>
                        <div className="text-sm text-muted-foreground">Effortlessly beautiful demos</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/product/capture" className="flex p-2">
                      <div>
                        <div className="font-medium">Lead Generation</div>
                        <div className="text-sm text-muted-foreground">Drive demand and pipeline</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/product/personalization" className="flex p-2">
                      <div>
                        <div className="font-medium">Personalization</div>
                        <div className="text-sm text-muted-foreground">Tailored storytelling at scale</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/integrations" className="flex p-2">
                      <div>
                        <div className="font-medium">Integrations</div>
                        <div className="text-sm text-muted-foreground">Connect Arcade with other tools</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/html-capture" className="flex p-2">
                      <div>
                        <div className="font-medium">HTML Capture</div>
                        <div className="text-sm text-muted-foreground">Modify page elements with AI-powered prompts</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/download" className="flex p-2">
                      <div>
                        <div className="font-medium">Arcade Desktop</div>
                        <div className="text-sm text-muted-foreground">Now available for web and macOS</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-1 font-medium">
                  Solutions <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60">
                <div className="grid gap-2 p-2">
                  <DropdownMenuItem asChild>
                    <Link href="/solutions/marketing" className="flex p-2">
                      <div>
                        <div className="font-medium">Marketing</div>
                        <div className="text-sm text-muted-foreground">From passive to interactive storytelling</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/solutions/product" className="flex p-2">
                      <div>
                        <div className="font-medium">Product</div>
                        <div className="text-sm text-muted-foreground">Demo-driven development</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/solutions/sales" className="flex p-2">
                      <div>
                        <div className="font-medium">Sales</div>
                        <div className="text-sm text-muted-foreground">Better conversations ahead</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-1 font-medium">
                  Resources <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60">
                <div className="grid gap-2 p-2">
                  <DropdownMenuItem asChild>
                    <Link href="/blog" className="flex p-2">
                      <div>
                        <div className="font-medium">Blog</div>
                        <div className="text-sm text-muted-foreground">The latest in all things interactive demos</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="https://docs.arcade.software/kb" className="flex p-2">
                      <div>
                        <div className="font-medium">Knowledge Base</div>
                        <div className="text-sm text-muted-foreground">Unlock your creativity and learning</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/changelog" className="flex p-2">
                      <div>
                        <div className="font-medium">Changelog</div>
                        <div className="text-sm text-muted-foreground">What's new in Arcade</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/showcase" className="flex p-2">
                      <div>
                        <div className="font-medium">Showcase</div>
                        <div className="text-sm text-muted-foreground">See best-in-class examples</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/category/case-study" className="flex p-2">
                      <div>
                        <div className="font-medium">Case studies</div>
                        <div className="text-sm text-muted-foreground">Stories from leading customers</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="gap-1 font-medium">
                  Company <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-60">
                <div className="grid gap-2 p-2">
                  <DropdownMenuItem asChild>
                    <Link href="/careers" className="flex p-2">
                      <div>
                        <div className="font-medium">Careers</div>
                        <div className="text-sm text-muted-foreground">Meet the team and see open roles</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/security" className="flex p-2">
                      <div>
                        <div className="font-medium">Security</div>
                        <div className="text-sm text-muted-foreground">Our commitment to customers</div>
                      </div>
                    </Link>
                  </DropdownMenuItem>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>

            <Link href="/pricing">
              <Button variant="ghost" className="font-medium">Pricing</Button>
            </Link>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-2">
          <Link href="https://app.arcade.software/auth">
            <Button variant="ghost" className="font-medium">Log in</Button>
          </Link>
          <Link href="https://app.arcade.software/auth">
            <Button variant="default" className="font-medium bg-primary hover:bg-primary/90 text-primary-foreground">
              Get started for free
            </Button>
          </Link>
          <Link href="https://app.arcade.software/flows">
            <Button variant="outline" className="font-medium">Open app</Button>
          </Link>
        </div>

        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild className="lg:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open Menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-full">
            <SheetHeader className="text-left text-lg font-medium">Menu</SheetHeader>
            <div className="flex flex-col gap-4 mt-6">
              <div className="flex flex-col gap-2">
                <div className="font-medium">Product</div>
                <Link href="/product" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Product Overview
                </Link>
                <Link href="/product/capture" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Lead Generation
                </Link>
                <Link href="/product/personalization" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Personalization
                </Link>
                <Link href="/integrations" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Integrations
                </Link>
                <Link href="/html-capture" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  HTML Capture
                </Link>
                <Link href="/download" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Arcade Desktop
                </Link>
              </div>

              <div className="flex flex-col gap-2">
                <div className="font-medium">Solutions</div>
                <Link href="/solutions/marketing" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Marketing
                </Link>
                <Link href="/solutions/product" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Product
                </Link>
                <Link href="/solutions/sales" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Sales
                </Link>
              </div>

              <div className="flex flex-col gap-2">
                <div className="font-medium">Resources</div>
                <Link href="/blog" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Blog
                </Link>
                <Link href="https://docs.arcade.software/kb" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Knowledge Base
                </Link>
                <Link href="/changelog" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Changelog
                </Link>
                <Link href="/showcase" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Showcase
                </Link>
                <Link href="/category/case-study" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Case studies
                </Link>
              </div>

              <div className="flex flex-col gap-2">
                <div className="font-medium">Company</div>
                <Link href="/careers" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Careers
                </Link>
                <Link href="/security" className="text-sm text-muted-foreground pl-4" onClick={() => setIsOpen(false)}>
                  Security
                </Link>
              </div>

              <Link href="/pricing" className="font-medium" onClick={() => setIsOpen(false)}>
                Pricing
              </Link>

              <div className="flex flex-col gap-2 mt-4">
                <Link href="https://app.arcade.software/auth" onClick={() => setIsOpen(false)}>
                  <Button variant="ghost" className="font-medium w-full">Log in</Button>
                </Link>
                <Link href="https://app.arcade.software/auth" onClick={() => setIsOpen(false)}>
                  <Button variant="default" className="font-medium w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    Get started for free
                  </Button>
                </Link>
                <Link href="https://app.arcade.software/flows" onClick={() => setIsOpen(false)}>
                  <Button variant="outline" className="font-medium w-full">Open app</Button>
                </Link>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
};

export default Navbar;
