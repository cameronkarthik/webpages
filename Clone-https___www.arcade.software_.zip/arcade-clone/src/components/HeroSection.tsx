'use client';

import { useEffect, useState, useMemo } from "react";
import { Button } from "./ui/button";
import Link from "next/link";

const HeroSection = () => {
  const [typewriterText, setTypewriterText] = useState("");
  const [typewriterIndex, setTypewriterIndex] = useState(0);
  const [showingComplete, setShowingComplete] = useState(false);

  const textOptions = useMemo(() => ["boring", "painful to make"], []);

  useEffect(() => {
    const intervalId = setInterval(() => {
      const currentText = textOptions[typewriterIndex];
      if (!showingComplete) {
        if (typewriterText.length < currentText.length) {
          setTypewriterText(currentText.slice(0, typewriterText.length + 1));
        } else {
          setShowingComplete(true);
          setTimeout(() => {
            setShowingComplete(false);
            setTypewriterText("");
            setTypewriterIndex((typewriterIndex + 1) % textOptions.length);
          }, 2000);
        }
      }
    }, 100);

    return () => clearInterval(intervalId);
  }, [typewriterText, typewriterIndex, showingComplete, textOptions]);

  return (
    <section className="relative pt-40 pb-32 overflow-hidden bg-gradient-to-b from-[#f7faff] via-[#f1f7ff] to-[#ffffff]">
      {/* Background Gradients */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-[15%] left-[-5%] w-[600px] h-[600px] bg-blue-100/30 rounded-full blur-[100px] opacity-60"></div>
        <div className="absolute top-[30%] right-[-5%] w-[600px] h-[600px] bg-pink-100/20 rounded-full blur-[100px] opacity-50"></div>
      </div>

      <div className="container relative z-10">
        <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
          {/* Announcement Banner */}
          <div className="inline-flex px-4 py-1.5 bg-blue-50 rounded-full text-sm text-primary font-medium mb-8 items-center">
            <Link href="/post/announcing-ai-powered-content-generation" className="flex items-center">
              <span>Announcing AI-Powered Content Generation</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="ml-1.5"
              >
                <path d="M7 7h10v10" />
                <path d="M7 17 17 7" />
              </svg>
            </Link>
          </div>

          {/* Main Heading with Typewriter Effect */}
          <div className="mb-6">
            <h1 className="text-5xl sm:text-6xl font-bold tracking-tight leading-tight">
              Product demos that <br className="hidden sm:block" />
              aren&apos;t <span className="relative">
                <span className="text-primary">{typewriterText}</span>
                <span
                  className="absolute -right-1 top-1/2 h-10 w-[2px] bg-primary animate-blink"
                  style={{
                    visibility: typewriterText.length < textOptions[typewriterIndex].length ? 'visible' : 'hidden',
                    transform: 'translateY(-50%)'
                  }}
                ></span>
              </span>
            </h1>
          </div>

          <p className="text-xl text-muted-foreground mb-10 max-w-2xl">
            Create interactive demos that convert in minutes.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto justify-center mb-16">
            <Link href="https://app.arcade.software/auth">
              <Button className="w-full sm:w-auto text-base bg-primary hover:bg-primary/90 text-primary-foreground font-medium px-8 py-6 h-auto rounded-md">
                Get started for free
              </Button>
            </Link>
            <Link href="/talk-to-sales">
              <Button variant="outline" className="w-full sm:w-auto text-base font-medium px-8 py-6 h-auto rounded-md border-gray-300">
                Talk to sales
              </Button>
            </Link>
          </div>

          {/* Play with this Arcade text with arrow */}
          <div className="relative mb-2">
            <span className="absolute right-[-60px] top-[-5px] text-primary rotate-12">
              <svg width="50" height="50" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M7 17L17 7M17 7H7M17 7V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </span>
            <p className="text-sm text-primary font-medium">Play with this Arcade</p>
          </div>

          {/* Logos Section */}
          <div className="mt-4 mb-8">
            <p className="text-sm text-muted-foreground mb-5">
              More than 15k companies choose Arcade to tell better product stories
            </p>
            <div className="flex flex-wrap justify-center gap-8 md:gap-10">
              <img src="https://ext.same-assets.com/3162312426/1520452126.svg+xml" alt="Rudderstack" className="h-6" />
              <img src="https://ext.same-assets.com/397154642/1131877454.svg+xml" alt="Zapier" className="h-6" />
              <img src="https://ext.same-assets.com/171606537/3341188870.svg+xml" alt="Sentry" className="h-6" />
              <img src="https://ext.same-assets.com/2636687690/3411835000.svg+xml" alt="Mux" className="h-6" />
              <img src="https://ext.same-assets.com/3215025526/146604453.svg+xml" alt="Hack The Box" className="h-6" />
              <img src="https://ext.same-assets.com/3555037457/2169250179.svg+xml" alt="Glide" className="h-6" />
              <img src="https://ext.same-assets.com/79075875/3475757591.svg+xml" alt="Clearbit" className="h-6" />
            </div>
          </div>

          {/* Stacked Panel Demo Effect */}
          <div className="relative w-full max-w-3xl mx-auto mt-12">
            {/* Background Panels - Stacked Effect */}
            <div className="absolute left-[5%] right-[5%] top-[10%] h-[90%] rounded-xl bg-white/20 backdrop-blur-sm border border-gray-100 shadow-sm transform rotate-[2deg] z-0"></div>
            <div className="absolute left-[2%] right-[2%] top-[5%] h-[90%] rounded-xl bg-white/30 backdrop-blur-sm border border-gray-100 shadow-sm transform rotate-[-1deg] z-10"></div>

            {/* Main Panel */}
            <div className="relative z-20 bg-gradient-to-r from-blue-500/5 to-indigo-500/5 rounded-xl border border-gray-200 p-6 shadow-sm backdrop-blur-md">
              <div className="flex justify-between items-center mb-4">
                <div className="flex gap-1.5">
                  <div className="w-3 h-3 rounded-full bg-red-400"></div>
                  <div className="w-3 h-3 rounded-full bg-yellow-400"></div>
                  <div className="w-3 h-3 rounded-full bg-green-400"></div>
                </div>
                <div className="text-xs text-muted-foreground">
                  arcade.software
                </div>
              </div>
              <div className="text-center py-16">
                <h3 className="text-xl font-medium mb-2">Introducing new</h3>
                <h2 className="text-3xl font-bold mb-8">Arcade creator tools</h2>
                <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">Try it out</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
